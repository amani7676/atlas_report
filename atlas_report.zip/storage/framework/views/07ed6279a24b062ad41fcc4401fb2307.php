<?php $__env->startSection('title', 'ویرایش دسته‌بندی'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">ویرایش دسته‌بندی</h3>
                </div>
                <div class="card-body">
                    <p>فرم ویرایش دسته‌بندی در حال توسعه است.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\atlas_report\resources\views\categories\edit.blade.php ENDPATH**/ ?>