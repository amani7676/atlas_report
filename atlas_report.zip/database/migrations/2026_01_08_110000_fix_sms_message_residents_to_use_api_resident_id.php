<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('sms_message_residents', function (Blueprint $table) {
            // حذف foreign key constraint قبلی
            $table->dropForeign(['resident_id']);
            
            // تغییر نوع ستون resident_id به integer برای ذخیره ID از API
            $table->integer('resident_id')->nullable()->comment('ID اقامتگر از API (نه ID جدول residents)')->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('sms_message_residents', function (Blueprint $table) {
            // بازگرداندن به حالت قبلی با foreign key
            $table->unsignedBigInteger('resident_id')->nullable()->comment('ID اقامتگر از API')->change();
            
            // ایجاد مجدد foreign key constraint
            $table->foreign('resident_id')
                ->references('id')
                ->on('residents')
                ->onDelete('set null');
        });
    }
};
