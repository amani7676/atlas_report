<div class="container mx-auto px-4 py-8" dir="rtl">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">تست ارسال پیامک الگویی</h2>

            <form wire:submit.prevent="sendTest">
                <!-- انتخاب الگو -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        انتخاب الگو <span class="text-red-500">*</span>
                    </label>
                    <select 
                        wire:model.live="selectedPattern" 
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                        <option value="">-- انتخاب الگو --</option>
                        @foreach($patterns as $pattern)
                            <option value="{{ $pattern->id }}">
                                {{ $pattern->title }} (کد: {{ $pattern->pattern_code }})
                            </option>
                        @endforeach
                    </select>
                    @error('selectedPattern')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- نمایش متن الگو -->
                @if($patternText)
                    <div class="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            متن الگو:
                        </label>
                        <div class="text-gray-800 whitespace-pre-wrap font-medium">
                            {{ $patternText }}
                        </div>
                    </div>
                @endif

                <!-- ورودی متغیرها -->
                @if(count($variables) > 0)
                    <div class="mb-6">
                        <div class="flex items-center justify-between mb-3">
                            <label class="block text-sm font-medium text-gray-700">
                                مقادیر متغیرها:
                            </label>
                            <div class="text-xs text-gray-500 bg-blue-50 px-3 py-1 rounded-full">
                                <i class="fas fa-info-circle"></i> مقادیر نمونه به صورت خودکار پر شده‌اند
                            </div>
                        </div>
                        <div class="space-y-3">
                            @foreach($variables as $variable)
                                <div class="flex items-center gap-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
                                    <div class="flex-shrink-0 w-32">
                                        <label class="text-sm text-gray-600 font-medium">
                                            {{ $variable['code'] }}
                                        </label>
                                        <div class="text-xs text-gray-500 mt-1">
                                            {{ $variable['title'] }}
                                        </div>
                                        @if($variable['table_field'])
                                            <div class="text-xs text-blue-600 mt-1">
                                                فیلد: {{ $variable['table_field'] }}
                                            </div>
                                        @endif
                                        @if(!$variable['exists_in_db'] ?? true)
                                            <div class="text-xs text-red-600 mt-1 bg-red-50 px-2 py-1 rounded">
                                                <i class="fas fa-exclamation-triangle"></i> تعریف نشده
                                            </div>
                                        @endif
                                    </div>
                                    <div class="flex-1">
                                        <input 
                                            type="text" 
                                            wire:model.live="variableValues.{{ $variable['index'] }}"
                                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                                            placeholder="مقدار {{ $variable['title'] }} را وارد کنید"
                                        >
                                        @if($variable['variable_type'] === 'user')
                                            <div class="text-xs text-green-600 mt-1">
                                                <i class="fas fa-user"></i> متغیر کاربری
                                            </div>
                                        @elseif($variable['variable_type'] === 'report')
                                            <div class="text-xs text-purple-600 mt-1">
                                                <i class="fas fa-file-alt"></i> متغیر گزارش
                                            </div>
                                        @elseif($variable['variable_type'] === 'general')
                                            <div class="text-xs text-orange-600 mt-1">
                                                <i class="fas fa-cog"></i> متغیر عمومی
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        
                        <!-- دکمه پر کردن مجدد مقادیر نمونه -->
                        <div class="mt-4 flex gap-2">
                            <button 
                                type="button"
                                wire:click="extractVariables"
                                class="text-sm text-blue-600 hover:text-blue-800 bg-blue-50 px-3 py-1 rounded-full border border-blue-200"
                            >
                                <i class="fas fa-refresh"></i> پر کردن مجدد مقادیر نمونه
                            </button>
                            
                            @if(count($variables) > 0)
                                <button 
                                    type="button"
                                    wire:click="debugVariables"
                                    class="text-sm text-orange-600 hover:text-orange-800 bg-orange-50 px-3 py-1 rounded-full border border-orange-200"
                                >
                                    <i class="fas fa-bug"></i> دیباگ متغیرها
                                </button>
                            @endif
                        </div>
                    </div>
                    
                    {{-- پیش‌نمایش پیام با متغیرهای جایگزین شده --}}
                    @if($previewMessage)
                        <div class="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200 border-r-4 border-r-blue-500">
                            <strong class="text-blue-700 block mb-3 flex items-center gap-2">
                                <i class="fas fa-eye"></i> پیش‌نمایش پیام ارسالی:
                            </strong>
                            <div class="bg-white p-4 rounded-lg border border-blue-200 text-gray-800 text-sm leading-relaxed">
                                {!! $previewMessage !!}
                            </div>
                            
                            @php
                                $variablesArray = [];
                                // پیدا کردن تمام ایندکس‌ها و مرتب کردن اونها (مثل کنترلر)
                                $indices = [];
                                foreach ($variables as $variable) {
                                    $indices[] = $variable['index'];
                                }
                                sort($indices);
                                
                                // پر کردن آرایه بر اساس ترتیب مرتب شده
                                foreach ($indices as $index) {
                                    $value = $variableValues[$index] ?? '';
                                    $variablesArray[] = $value;
                                }
                            @endphp
                            
                            @if(count($variablesArray) > 0)
                                <div class="mt-4 pt-4 border-t border-blue-200">
                                    <strong class="text-gray-600 text-xs block mb-2">متغیرهای ارسالی به API:</strong>
                                    <div class="flex flex-wrap gap-2 mb-3">
                                        @foreach($variables as $variable)
                                            @php
                                                $index = $variable['index'];
                                                $value = $variableValues[$index] ?? '';
                                            @endphp
                                            <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-mono">
                                                { {{ $index }} }: {{ $value ?: '[خالی]' }}
                                            </span>
                                        @endforeach
                                    </div>
                                    <div class="bg-gray-100 p-3 rounded">
                                        <strong class="text-gray-600 text-xs block mb-1">رشته ارسالی به API (با جداکننده ;):</strong>
                                        <code class="block mt-1 p-2 bg-white rounded text-xs text-left direction-ltr break-all">
                                            {{ implode(';', $variablesArray) }}
                                        </code>
                                    </div>
                                    
                                    <!-- نمایش تطابق با الگو -->
                                    <div class="mt-3 p-3 bg-yellow-50 rounded border border-yellow-200">
                                        <strong class="text-yellow-700 text-xs block mb-1">
                                            <i class="fas fa-info-circle"></i> بررسی تطابق:
                                        </strong>
                                        @php
                                            preg_match_all('/\{(\d+)\}/', $patternText, $patternMatches);
                                            $expectedCount = count(array_unique($patternMatches[1]));
                                            $actualCount = count($variablesArray);
                                        @endphp
                                        <div class="text-xs text-yellow-800 mt-1">
                                            متغیرهای مورد انتظار: {{ $expectedCount }} | متغیرهای وارد شده: {{ $actualCount }}
                                            @if($expectedCount == $actualCount)
                                                <span class="text-green-600 font-medium"> ✓ تطابق دارد</span>
                                            @else
                                                <span class="text-red-600 font-medium"> ✗ تطابق ندارد</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @endif
                        </div>
                    @endif
                @endif

                <!-- شماره فرستنده -->
                <div class="mb-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-phone-alt text-yellow-600"></i> شماره فرستنده <span class="text-red-500">*</span>
                    </label>
                    @if(count($availableSenderNumbers) > 0)
                        <select wire:model.live="selectedSenderNumberId" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 mb-2">
                            @foreach($availableSenderNumbers as $sender)
                                <option value="{{ $sender->id }}">
                                    {{ $sender->title }} ({{ $sender->number }})
                                    @if($sender->api_key)
                                        - دارای API Key
                                    @endif
                                </option>
                            @endforeach
                        </select>
                        <div class="flex items-center gap-2">
                            <span class="text-lg font-bold text-gray-800 font-mono">{{ $senderNumber }}</span>
                        </div>
                    @else
                        <div class="flex items-center gap-2">
                            <span class="text-lg font-bold text-gray-800 font-mono">{{ $senderNumber }}</span>
                            @if($senderNumber === 'تنظیم نشده')
                                <span class="text-xs text-red-600 bg-red-100 px-2 py-1 rounded">
                                    (لطفاً در فایل .env تنظیم کنید)
                                </span>
                            @endif
                        </div>
                    @endif
                    <p class="mt-2 text-xs text-gray-600">
                        @if(count($availableSenderNumbers) > 0)
                            شماره فرستنده را از لیست انتخاب کنید. برای مدیریت شماره‌ها به 
                            <a href="/sender-numbers" target="_blank" class="text-blue-600 underline">صفحه مدیریت شماره‌های فرستنده</a> بروید.
                        @else
                            این شماره برای ارسال پیامک الگویی استفاده می‌شود. برای تغییر، متغیر <code class="bg-gray-100 px-1 rounded">MELIPAYAMAK_PATTERN_FROM</code> را در فایل <code class="bg-gray-100 px-1 rounded">.env</code> تنظیم کنید یا از 
                            <a href="/sender-numbers" target="_blank" class="text-blue-600 underline">صفحه مدیریت شماره‌های فرستنده</a> استفاده کنید.
                        @endif
                    </p>
                </div>

                <!-- شماره تلفن -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        شماره تلفن گیرنده <span class="text-red-500">*</span>
                    </label>
                    <input 
                        type="text" 
                        wire:model="phone"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="09123456789"
                        maxlength="11"
                    >
                    @error('phone')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- دکمه ارسال -->
                <div class="flex justify-end gap-4">
                    <button 
                        type="submit"
                        class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        wire:loading.attr="disabled"
                    >
                        <span wire:loading.remove wire:target="sendTest">
                            ارسال تست
                        </span>
                        <span wire:loading wire:target="sendTest">
                            در حال ارسال...
                        </span>
                    </button>
                </div>
            </form>

            <!-- نمایش نتیجه -->
            @if($showResult && $result)
                <div class="mt-8 p-6 bg-gray-50 rounded-lg border border-gray-200">
                    <h3 class="text-xl font-bold mb-4 text-gray-800">پاسخ API ملی پیامک</h3>
                    
                    <div class="space-y-4">
                        <!-- وضعیت -->
                        <div class="flex items-center gap-2">
                            <span class="font-medium text-gray-700">وضعیت:</span>
                            @if($result['success'] ?? false)
                                <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                                    ✅ موفق
                                </span>
                            @else
                                <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-medium">
                                    ❌ ناموفق
                                </span>
                            @endif
                        </div>

                        <!-- پیام -->
                        @if(isset($result['message']))
                            <div>
                                <span class="font-medium text-gray-700">پیام:</span>
                                <p class="mt-1 text-gray-800">{{ $result['message'] }}</p>
                            </div>
                        @endif

                        <!-- RecId -->
                        @if(isset($result['rec_id']))
                            <div>
                                <span class="font-medium text-gray-700">RecId:</span>
                                <p class="mt-1 text-gray-800 font-mono">{{ $result['rec_id'] }}</p>
                            </div>
                        @endif

                        <!-- کد پاسخ -->
                        @if(isset($result['response_code']))
                            <div>
                                <span class="font-medium text-gray-700">کد پاسخ:</span>
                                <p class="mt-1 text-gray-800 font-mono">{{ $result['response_code'] }}</p>
                            </div>
                        @endif

                        <!-- پاسخ خام -->
                        @if(isset($result['raw_response']))
                            <div>
                                <span class="font-medium text-gray-700">پاسخ خام API:</span>
                                <div class="mt-2 p-3 bg-white rounded border border-gray-300">
                                    <pre class="text-sm text-gray-800 whitespace-pre-wrap break-words">{{ $result['raw_response'] }}</pre>
                                </div>
                            </div>
                        @endif

                        <!-- پاسخ API (JSON) -->
                        @if(isset($result['api_response']))
                            <div>
                                <span class="font-medium text-gray-700">پاسخ API (JSON):</span>
                                <div class="mt-2 p-3 bg-white rounded border border-gray-300">
                                    <pre class="text-sm text-gray-800 whitespace-pre-wrap break-words">{{ is_array($result['api_response']) ? json_encode($result['api_response'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) : $result['api_response'] }}</pre>
                                </div>
                            </div>
                        @endif

                        <!-- خطا -->
                        @if(isset($result['error']))
                            <div>
                                <span class="font-medium text-red-700">خطا:</span>
                                <p class="mt-1 text-red-800">{{ $result['error'] }}</p>
                            </div>
                        @endif

                        <!-- اطلاعات کامل (برای دیباگ) -->
                        <details class="mt-4">
                            <summary class="cursor-pointer text-sm font-medium text-gray-600 hover:text-gray-800">
                                نمایش اطلاعات کامل (برای دیباگ)
                            </summary>
                            <div class="mt-2 p-3 bg-white rounded border border-gray-300">
                                <pre class="text-xs text-gray-800 whitespace-pre-wrap break-words">{{ json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) }}</pre>
                            </div>
                        </details>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>


