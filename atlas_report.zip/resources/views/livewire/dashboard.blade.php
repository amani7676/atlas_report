<div>
    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <h2 style="margin: 0;">داشبورد مدیریت</h2>
                <p style="margin: 5px 0 0 0;">سیستم گزارش‌گیری اقامت‌گران</p>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
                @if($orphanedRecordsCount > 0)
                    <span style="background: #dc3545; color: white; padding: 6px 12px; border-radius: 20px; font-size: 14px; font-weight: bold;">
                        {{ $orphanedRecordsCount }}
                    </span>
                @else
                    <span style="background: #6c757d; color: white; padding: 6px 12px; border-radius: 20px; font-size: 14px;">
                        0
                    </span>
                @endif
                <button wire:click="cleanupOrphanedRecords" wire:loading.attr="disabled" class="btn btn-primary" style="display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-trash-alt" wire:loading.class="fa-spin"></i>
                    <span wire:loading.remove>نیاز به حذف اطلاعات به درد نخور</span>
                    <span wire:loading>در حال پردازش...</span>
                </button>
            </div>
        </div>
    </div>

    <div class="grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 20px;">
        <style>
            @media (max-width: 768px) {
                .grid {
                    grid-template-columns: 1fr !important;
                }
            }
        </style>
        <div class="stats-card">
            <i class="fas fa-file-alt" style="font-size: 24px;"></i>
            <div class="stats-number">{{ $totalReports }}</div>
            <div class="stats-label">گزارش‌های ثبت‌شده</div>
        </div>

        <div class="stats-card" style="background: linear-gradient(135deg, #4cc9f0, #2db8d9);">
            <i class="fas fa-list" style="font-size: 24px;"></i>
            <div class="stats-number">{{ $totalCategories }}</div>
            <div class="stats-label">دسته‌بندی‌ها</div>
        </div>

        <div class="stats-card" style="background: linear-gradient(135deg, #06ffa5, #00c896);">
            <i class="fas fa-paper-plane" style="font-size: 24px;"></i>
            <div class="stats-number">{{ $totalSentMessages }}</div>
            <div class="stats-label">پیام‌های ارسال شده</div>
        </div>

        <div class="stats-card" style="background: linear-gradient(135deg, #ff6b6b, #ee5a52);">
            <i class="fas fa-exclamation-triangle" style="font-size: 24px;"></i>
            <div class="stats-number">{{ $failedMessages }}</div>
            <div class="stats-label">پیام‌های ناموفق</div>
        </div>

        <div class="stats-card" style="background: linear-gradient(135deg, #4ecdc4, #44a3aa);">
            <i class="fas fa-check-circle" style="font-size: 24px;"></i>
            <div class="stats-number">{{ $deliveryStats['delivered'] ?? 0 }}</div>
            <div class="stats-label">پیام‌های تحویل شده</div>
        </div>

        <div class="stats-card" style="background: linear-gradient(135deg, #f7b731, #f5a623);">
            <i class="fas fa-clock" style="font-size: 24px;"></i>
            <div class="stats-number">{{ $deliveryStats['delivery_pending'] ?? 0 }}</div>
            <div class="stats-label">در انتظار دلیوری</div>
        </div>
    </div>

    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 style="margin: 0;">آخرین پیام‌های ارسال شده</h3>
            <div style="display: flex; align-items: center; gap: 10px;">
                @if($lastDeliveryCheck)
                    <span style="color: #666; font-size: 12px;">
                        آخرین بررسی دلیوری: {{ jalaliDate($lastDeliveryCheck, 'Y/m/d H:i') }}
                    </span>
                @endif
                <button wire:click="updateDeliveryStatus" wire:loading.attr="disabled" class="btn btn-info btn-sm" style="display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-sync" wire:loading.class="fa-spin"></i>
                    <span wire:loading.remove>بررسی وضعیت دلیوری</span>
                    <span wire:loading>در حال بررسی...</span>
                </button>
                <a href="{{ route('sms.sent') }}" style="color: #007bff; text-decoration: none; font-size: 14px;">
                    مشاهده همه <i class="fas fa-arrow-left"></i>
                </a>
            </div>
        </div>

        @if($recentSentMessages->count() > 0)
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>نام اقامت‌گر</th>
                            <th>متن پیام</th>
                            <th>وضعیت ارسال</th>
                            <th>وضعیت دلیوری</th>
                            <th>تاریخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recentSentMessages as $message)
                            <tr>
                                <td>{{ $message->resident_name }}</td>
                                <td>
                                    <div style="max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="{{ $message->smsMessage->text ?? '' }}">
                                        {{ $message->smsMessage->text ?? 'نامشخص' }}
                                    </div>
                                </td>
                                <td>
                                    @if($message->status == 'sent')
                                        <span style="background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                            <i class="fas fa-check"></i> ارسال شده
                                        </span>
                                    @elseif($message->status == 'delivered')
                                        <span style="background: #d1ecf1; color: #0c5460; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                            <i class="fas fa-check-double"></i> تحویل شده
                                        </span>
                                    @elseif($message->status == 'failed')
                                        <span style="background: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                            <i class="fas fa-times"></i> ناموفق
                                        </span>
                                    @else
                                        <span style="background: #fff3cd; color: #856404; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                            <i class="fas fa-clock"></i> در انتظار
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    @if($message->delivery_checked)
                                        @if($message->delivery_status == 1)
                                            <span style="background: #d1ecf1; color: #0c5460; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                                <i class="fas fa-check-double"></i> رسیده به گوشی
                                            </span>
                                        @elseif($message->delivery_status == 0)
                                            <span style="background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                                <i class="fas fa-check"></i> رسیده به مخابرات
                                            </span>
                                        @elseif(in_array($message->delivery_status, [2, 3, 5, 16, 35]))
                                            <span style="background: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                                <i class="fas fa-times"></i> تحویل نشد
                                            </span>
                                        @else
                                            <span style="background: #e2e3e5; color: #383d41; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                                کد: {{ $message->delivery_status ?? 'نامشخص' }}
                                            </span>
                                        @endif
                                    @else
                                        <span style="background: #fff3cd; color: #856404; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                            <i class="fas fa-clock"></i> بررسی نشده
                                        </span>
                                    @endif
                                </td>
                                <td>{{ jalaliDate($message->created_at, 'Y/m/d H:i') }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div style="text-align: center; padding: 40px; color: #666;">
                <i class="fas fa-sms" style="font-size: 48px; margin-bottom: 20px; opacity: 0.5;"></i>
                <p>هنوز هیچ پیامی ارسال نشده است</p>
            </div>
        @endif
    </div>
</div>
