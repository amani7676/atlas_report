@extends('layouts.app')

@section('title', 'ایجاد گزارش جدید')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">ایجاد گزارش جدید</h3>
                </div>
                <div class="card-body">
                    <p>فرم ایجاد گزارش در حال توسعه است.</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
