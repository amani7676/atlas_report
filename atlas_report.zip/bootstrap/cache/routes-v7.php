<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/livewire/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'default.livewire.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.min.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KDe419kC6D0nNZfl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.min.js.map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZevkvWzAnyBHYe5s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/upload-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.upload-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MwGPo7Q5hF1OufyU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/categories/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/residents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'residents.units',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/resident-reports' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'residents.reports',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/resident-reports/notifications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'residents.notification-reports',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/residents/expired-today' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'residents.expired-today',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/residents/group-sms' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'residents.group-sms',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reports/violations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports.violations',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/blacklists' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'blacklists.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/patterns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'patterns.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/patterns/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'patterns.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/variables' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'variables.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/variables/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'variables.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sender-numbers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sender-numbers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api-keys' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api-keys.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api-manager' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api-manager.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/constants' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'constants.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/table-names' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'table-names.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'settings.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sms/sent' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sms.sent',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sms/api-messages' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sms.api-messages',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/test-sync' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K6XjAkQqDE7tvq8H',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-api-url' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WmxuEeZRG0zSaWhu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sync-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BfunPQy856trWGSh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sync-data-live' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Lo9WyashZVwdTF2C',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/residents/sync' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jyOKRd7YbrMpdew7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/residents/sync-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bkR3m5KDRsE4hjbp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/residents/last-sync' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HwChn9xEyEqVLSF4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reports/bulk-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports.bulk-delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/categories/bulk-delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.bulk-delete',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/residents/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.residents.all',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reports/endpoints' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.reports.endpoints',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/violations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.admin.violations',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/livewire/preview\\-file/([^/]++)(*:39)|/reports/edit/([^/]++)(*:68)|/categories/edit/([^/]++)(*:100)|/api/resident/([^/]++)(*:130)|/storage/(.*)(?|(*:154)))/?$}sDu',
    ),
    3 => 
    array (
      39 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.preview-file',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      68 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reports.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      100 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'categories.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      130 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'api.resident.data',
          ),
          1 => 
          array (
            0 => 'residentId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local.upload',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'default.livewire.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/update',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\HandleRequests\\HandleRequests@handleUpdate',
        'controller' => 'Livewire\\Mechanisms\\HandleRequests\\HandleRequests@handleUpdate',
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'default.livewire.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KDe419kC6D0nNZfl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.min.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@returnJavaScriptAsFile',
        'controller' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@returnJavaScriptAsFile',
        'as' => 'generated::KDe419kC6D0nNZfl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZevkvWzAnyBHYe5s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.min.js.map',
      'action' => 
      array (
        'uses' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@maps',
        'controller' => 'Livewire\\Mechanisms\\FrontendAssets\\FrontendAssets@maps',
        'as' => 'generated::ZevkvWzAnyBHYe5s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.upload-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/upload-file',
      'action' => 
      array (
        'uses' => 'Livewire\\Features\\SupportFileUploads\\FileUploadController@handle',
        'controller' => 'Livewire\\Features\\SupportFileUploads\\FileUploadController@handle',
        'as' => 'livewire.upload-file',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.preview-file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/preview-file/{filename}',
      'action' => 
      array (
        'uses' => 'Livewire\\Features\\SupportFileUploads\\FilePreviewController@handle',
        'controller' => 'Livewire\\Features\\SupportFileUploads\\FilePreviewController@handle',
        'as' => 'livewire.preview-file',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MwGPo7Q5hF1OufyU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:831:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'C:\\\\laragon\\\\www\\\\atlas_report\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"000000000000074e0000000000000000";}}',
        'as' => 'generated::MwGPo7Q5hF1OufyU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Livewire\\Auth\\Login@__invoke',
        'controller' => 'App\\Livewire\\Auth\\Login',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Livewire\\Auth\\Register@__invoke',
        'controller' => 'App\\Livewire\\Auth\\Register',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:143:"function () {
    \\auth()->logout();
    \\session()->invalidate();
    \\session()->regenerateToken();
    return \\redirect()->route(\'login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007540000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:137:"function () {
    if (\\auth()->check()) {
        return \\redirect()->route(\'dashboard\');
    }
    return \\redirect()->route(\'login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007560000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Dashboard@__invoke',
        'controller' => 'App\\Livewire\\Dashboard',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Reports\\Index@__invoke',
        'controller' => 'App\\Livewire\\Reports\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reports.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Reports\\Create@__invoke',
        'controller' => 'App\\Livewire\\Reports\\Create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reports.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Reports\\Edit@__invoke',
        'controller' => 'App\\Livewire\\Reports\\Edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reports.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Categories\\Index@__invoke',
        'controller' => 'App\\Livewire\\Categories\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'categories.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'categories/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Categories\\Create@__invoke',
        'controller' => 'App\\Livewire\\Categories\\Create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'categories.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'categories/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Categories\\Edit@__invoke',
        'controller' => 'App\\Livewire\\Categories\\Edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'categories.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'residents.units' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'residents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Residents\\Units@__invoke',
        'controller' => 'App\\Livewire\\Residents\\Units',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'residents.units',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'residents.reports' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'resident-reports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Residents\\ResidentReports@__invoke',
        'controller' => 'App\\Livewire\\Residents\\ResidentReports',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'residents.reports',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'residents.notification-reports' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'resident-reports/notifications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Residents\\NotificationReports@__invoke',
        'controller' => 'App\\Livewire\\Residents\\NotificationReports',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'residents.notification-reports',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'residents.expired-today' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'residents/expired-today',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Residents\\ExpiredToday@__invoke',
        'controller' => 'App\\Livewire\\Residents\\ExpiredToday',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'residents.expired-today',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'residents.group-sms' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'residents/group-sms',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Residents\\GroupSms@__invoke',
        'controller' => 'App\\Livewire\\Residents\\GroupSms',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'residents.group-sms',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.violations' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reports/violations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Reports\\Violations@__invoke',
        'controller' => 'App\\Livewire\\Reports\\Violations',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reports.violations',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'blacklists.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'blacklists',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Blacklists\\Index@__invoke',
        'controller' => 'App\\Livewire\\Blacklists\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'blacklists.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'patterns.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'patterns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Patterns\\Index@__invoke',
        'controller' => 'App\\Livewire\\Patterns\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'patterns.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'patterns.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'patterns/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Patterns\\Index@__invoke',
        'controller' => 'App\\Livewire\\Patterns\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'patterns.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'variables.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'variables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Variables\\Index@__invoke',
        'controller' => 'App\\Livewire\\Variables\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'variables.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'variables.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'variables/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Variables\\Index@__invoke',
        'controller' => 'App\\Livewire\\Variables\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'variables.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sender-numbers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sender-numbers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Admin\\SenderNumbers@__invoke',
        'controller' => 'App\\Livewire\\Admin\\SenderNumbers',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sender-numbers.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-keys.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api-keys',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Admin\\ApiKeyManager@__invoke',
        'controller' => 'App\\Livewire\\Admin\\ApiKeyManager',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'api-keys.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api-manager.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api-manager',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Admin\\ApiManager@__invoke',
        'controller' => 'App\\Livewire\\Admin\\ApiManager',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'api-manager.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'constants.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'constants',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Constants\\Index@__invoke',
        'controller' => 'App\\Livewire\\Constants\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'constants.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'table-names.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'table-names',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\TableNames\\Index@__invoke',
        'controller' => 'App\\Livewire\\TableNames\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'table-names.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'settings.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Settings\\Index@__invoke',
        'controller' => 'App\\Livewire\\Settings\\Index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'settings.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sms.sent' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sms/sent',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Sms\\SentMessages@__invoke',
        'controller' => 'App\\Livewire\\Sms\\SentMessages',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sms.sent',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sms.api-messages' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sms/api-messages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Livewire\\Sms\\ApiMessages@__invoke',
        'controller' => 'App\\Livewire\\Sms\\ApiMessages',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'sms.api-messages',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K6XjAkQqDE7tvq8H' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'test-sync',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:103:"function () {
    return \\response()->json([\'success\' => true, \'message\' => \'Test endpoint works!\']);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007720000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::K6XjAkQqDE7tvq8H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WmxuEeZRG0zSaWhu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'update-api-url',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:502:"function () {
    try {
        $settings = \\App\\Models\\Settings::getSettings();
        $settings->api_url = \'http://127.0.0.1:8000/api/residents\';
        $settings->save();
        
        return \\response()->json([
            \'success\' => true,
            \'message\' => \'API URL updated to: \' . $settings->api_url
        ]);
    } catch (\\Exception $e) {
        return \\response()->json([
            \'success\' => false,
            \'message\' => \'Error: \' . $e->getMessage()
        ]);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007740000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WmxuEeZRG0zSaWhu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BfunPQy856trWGSh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sync-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:8693:"function () {
    try {
        // \\Log::info(\'=== Starting sync using settings API ===\');
        
        // 1. پاک کردن کل جدول
        $deletedCount = \\App\\Models\\Resident::count();
        \\App\\Models\\Resident::query()->delete();
        \\Illuminate\\Support\\Facades\\DB::statement(\'ALTER TABLE residents AUTO_INCREMENT = 1\');
        // \\Log::info("Deleted {$deletedCount} residents from database");
        
        // 2. دریافت URL از تنظیمات
        $settings = \\App\\Models\\Settings::getSettings();
        $apiUrl = $settings->api_url ?? null;
        
        if (!$apiUrl) {
            throw new \\Exception("API URL not set in settings. Please configure \'لینک API اقامت‌گران\' in settings.");
        }
        
        $primaryApiUrl = $apiUrl;
        $fallbackApiUrl = \'http://127.0.0.1:8000/api/residents\'; // fallback لوکال
        
        // \\Log::info("Primary API URL: {$primaryApiUrl}");
        // \\Log::info("Fallback API URL: {$fallbackApiUrl}");
        
        // 3. تلاش برای دریافت داده‌ها از API اصلی، سپس از fallback
        $apiUrl = $primaryApiUrl;
        $response = null;
        $httpCode = 0;
        
        // تلاش اول با API اصلی
        for ($attempt = 1; $attempt <= 2; $attempt++) {
            // \\Log::info("Attempt {$attempt}: Trying API URL: {$apiUrl}");
            
            $ch = \\curl_init();
            \\curl_setopt($ch, CURLOPT_URL, $apiUrl);
            \\curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            \\curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            \\curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            \\curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            \\curl_setopt($ch, CURLOPT_USERAGENT, \'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\');
            
            $response = \\curl_exec($ch);
            $httpCode = \\curl_getinfo($ch, CURLINFO_HTTP_CODE);
            \\curl_close($ch);
            
            // \\Log::info("API Response - HTTP {$httpCode} from {$apiUrl}");
            
            if ($httpCode === 200) {
                // \\Log::info("API request successful on attempt {$attempt}");
                break;
            } else {
                // \\Log::warning("API request failed on attempt {$attempt}: HTTP {$httpCode}");
                
                // اگر تلاش اول ناموفق بود، از fallback استفاده کن
                if ($attempt === 1) {
                    $apiUrl = $fallbackApiUrl;
                    // \\Log::info("Switching to fallback API: {$apiUrl}");
                } else {
                    // هر دو تلاش ناموفق بودند
                    throw new \\Exception("Both APIs failed. Primary: HTTP {$httpCode} from {$primaryApiUrl}, Fallback: HTTP {$httpCode} from {$fallbackApiUrl}");
                }
            }
        }
        
        $residents = \\json_decode($response, true);
        if (\\json_last_error() !== JSON_ERROR_NONE) {
            throw new \\Exception("JSON decode error: " . \\json_last_error_msg());
        }
        
        if (empty($residents) || !\\is_array($residents)) {
            throw new \\Exception("No data received from API");
        }
        
        $residents = \\array_values($residents);
        // \\Log::info("API returned " . count($residents) . " residents");
        
        // 4. درج داده‌های جدید
        $createdCount = 0;
        foreach ($residents as $item) {
            if (!isset($item[\'resident_id\'])) {
                continue;
            }
            
            \\App\\Models\\Resident::create([
                \'resident_id\' => $item[\'resident_id\'],
                \'contract_id\' => $item[\'contract_id\'] ?? null,
                \'unit_id\' => $item[\'unit_id\'] ?? null,
                \'unit_name\' => $item[\'unit_name\'] ?? null,
                \'unit_code\' => $item[\'unit_code\'] ?? null,
                \'unit_desc\' => $item[\'unit_desc\'] ?? null,
                \'unit_created_at\' => $item[\'unit_created_at\'] ?? null,
                \'unit_updated_at\' => $item[\'unit_updated_at\'] ?? null,
                \'room_id\' => $item[\'room_id\'] ?? null,
                \'room_name\' => $item[\'room_name\'] ?? null,
                \'room_code\' => $item[\'room_code\'] ?? null,
                \'room_unit_id\' => $item[\'room_unit_id\'] ?? null,
                \'room_bed_count\' => $item[\'room_bed_count\'] ?? null,
                \'room_desc\' => $item[\'room_desc\'] ?? null,
                \'room_type\' => $item[\'room_type\'] ?? null,
                \'room_created_at\' => $item[\'room_created_at\'] ?? null,
                \'room_updated_at\' => $item[\'room_updated_at\'] ?? null,
                \'bed_id\' => $item[\'bed_id\'] ?? null,
                \'bed_name\' => $item[\'bed_name\'] ?? null,
                \'bed_code\' => $item[\'bed_code\'] ?? null,
                \'bed_room_id\' => $item[\'bed_room_id\'] ?? null,
                \'bed_state_ratio_resident\' => $item[\'bed_state_ratio_resident\'] ?? null,
                \'bed_state\' => $item[\'bed_state\'] ?? null,
                \'bed_desc\' => $item[\'bed_desc\'] ?? null,
                \'bed_created_at\' => $item[\'bed_created_at\'] ?? null,
                \'bed_updated_at\' => $item[\'bed_updated_at\'] ?? null,
                \'contract_resident_id\' => $item[\'contract_resident_id\'] ?? null,
                \'contract_payment_date\' => $item[\'contract_payment_date\'] ?? null,
                \'contract_payment_date_jalali\' => $item[\'contract_payment_date_jalali\'] ?? null,
                \'contract_bed_id\' => $item[\'contract_bed_id\'] ?? null,
                \'contract_state\' => $item[\'contract_state\'] ?? null,
                \'contract_start_date\' => $item[\'contract_start_date\'] ?? null,
                \'contract_start_date_jalali\' => $item[\'contract_start_date_jalali\'] ?? null,
                \'contract_end_date\' => $item[\'contract_end_date\'] ?? null,
                \'contract_end_date_jalali\' => $item[\'contract_end_date_jalali\'] ?? null,
                \'contract_created_at\' => $item[\'contract_created_at\'] ?? null,
                \'contract_updated_at\' => $item[\'contract_updated_at\'] ?? null,
                \'contract_deleted_at\' => $item[\'contract_deleted_at\'] ?? null,
                \'resident_full_name\' => $item[\'resident_full_name\'] ?? null,
                \'resident_phone\' => $item[\'resident_phone\'] ?? null,
                \'resident_age\' => $item[\'resident_age\'] ?? null,
                \'resident_birth_date\' => $item[\'resident_birth_date\'] ?? null,
                \'resident_job\' => $item[\'resident_job\'] ?? null,
                \'resident_referral_source\' => $item[\'resident_referral_source\'] ?? null,
                \'resident_form\' => $item[\'resident_form\'] ?? false,
                \'resident_document\' => $item[\'resident_document\'] ?? false,
                \'resident_rent\' => $item[\'resident_rent\'] ?? false,
                \'resident_trust\' => $item[\'resident_trust\'] ?? false,
                \'resident_created_at\' => $item[\'resident_created_at\'] ?? null,
                \'resident_updated_at\' => $item[\'resident_updated_at\'] ?? null,
                \'resident_deleted_at\' => $item[\'resident_deleted_at\'] ?? null,
                \'notes\' => $item[\'notes\'] ?? null,
                \'delay\' => $item[\'delay\'] ?? 0,
                \'last_synced_at\' => \\now(),
            ]);
            
            $createdCount++;
        }
        
        // \\Log::info("Created {$createdCount} new residents");
        
        // 5. ذخیره cache
        \\Illuminate\\Support\\Facades\\Cache::put(\'residents_last_sync\', [
            \'time\' => \\now()->format(\'Y-m-d H:i:s\'),
            \'synced_count\' => $createdCount,
            \'created_count\' => $createdCount,
            \'updated_count\' => 0,
            \'deleted_count\' => $deletedCount,
            \'message\' => "دیتابیس از {$apiUrl} جایگزین شد. حذف شده: {$deletedCount}, ایجاد شده: {$createdCount}",
        ], \\now()->addDays(7));
        
        $totalInDb = \\App\\Models\\Resident::count();
        
        return \\response()->json([
            \'success\' => true,
            \'message\' => "همگام‌سازی موفق از {$apiUrl}: {$deletedCount} حذف، {$createdCount} ایجاد شد. مجموع: {$totalInDb} رکورد."
        ]);
        
    } catch (\\Exception $e) {
        \\Log::error(\'=== Sync failed ===\', [
            \'error\' => $e->getMessage(),
            \'trace\' => $e->getTraceAsString()
        ]);
        
        return \\response()->json([
            \'success\' => false,
            \'message\' => \'خطا: \' . $e->getMessage()
        ], 500);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007760000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BfunPQy856trWGSh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Lo9WyashZVwdTF2C' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sync-data-live',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:7118:"function () {
    try {
        \\Log::info(\'=== Starting sync with LIVE API ===\');
        
        // 1. پاک کردن کل جدول
        $deletedCount = \\App\\Models\\Resident::count();
        \\App\\Models\\Resident::query()->delete();
        \\Illuminate\\Support\\Facades\\DB::statement(\'ALTER TABLE residents AUTO_INCREMENT = 1\');
        \\Log::info("Deleted {$deletedCount} residents from database");
        
        // 2. دریافت داده‌ها از API هاست
        $apiUrl = \'http://atlasdorm.com/api/residents\';
        \\Log::info("Fetching data from LIVE API: {$apiUrl}");
        
        $ch = \\curl_init();
        \\curl_setopt($ch, CURLOPT_URL, $apiUrl);
        \\curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        \\curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        \\curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        \\curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        \\curl_setopt($ch, CURLOPT_USERAGENT, \'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\');
        
        $response = \\curl_exec($ch);
        $httpCode = \\curl_getinfo($ch, CURLINFO_HTTP_CODE);
        \\curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new \\Exception("LIVE API request failed: HTTP {$httpCode}");
        }
        
        $residents = \\json_decode($response, true);
        if (\\json_last_error() !== JSON_ERROR_NONE) {
            throw new \\Exception("JSON decode error: " . \\json_last_error_msg());
        }
        
        if (empty($residents) || !\\is_array($residents)) {
            throw new \\Exception("No data received from LIVE API");
        }
        
        $residents = \\array_values($residents);
        \\Log::info("LIVE API returned " . \\count($residents) . " residents");
        
        // 3. درج داده‌های جدید
        $createdCount = 0;
        foreach ($residents as $item) {
            if (!isset($item[\'resident_id\'])) {
                continue;
            }
            
            \\App\\Models\\Resident::create([
                \'resident_id\' => $item[\'resident_id\'],
                \'contract_id\' => $item[\'contract_id\'] ?? null,
                \'unit_id\' => $item[\'unit_id\'] ?? null,
                \'unit_name\' => $item[\'unit_name\'] ?? null,
                \'unit_code\' => $item[\'unit_code\'] ?? null,
                \'unit_desc\' => $item[\'unit_desc\'] ?? null,
                \'unit_created_at\' => $item[\'unit_created_at\'] ?? null,
                \'unit_updated_at\' => $item[\'unit_updated_at\'] ?? null,
                \'room_id\' => $item[\'room_id\'] ?? null,
                \'room_name\' => $item[\'room_name\'] ?? null,
                \'room_code\' => $item[\'room_code\'] ?? null,
                \'room_unit_id\' => $item[\'room_unit_id\'] ?? null,
                \'room_bed_count\' => $item[\'room_bed_count\'] ?? null,
                \'room_desc\' => $item[\'room_desc\'] ?? null,
                \'room_type\' => $item[\'room_type\'] ?? null,
                \'room_created_at\' => $item[\'room_created_at\'] ?? null,
                \'room_updated_at\' => $item[\'room_updated_at\'] ?? null,
                \'bed_id\' => $item[\'bed_id\'] ?? null,
                \'bed_name\' => $item[\'bed_name\'] ?? null,
                \'bed_code\' => $item[\'bed_code\'] ?? null,
                \'bed_room_id\' => $item[\'bed_room_id\'] ?? null,
                \'bed_state_ratio_resident\' => $item[\'bed_state_ratio_resident\'] ?? null,
                \'bed_state\' => $item[\'bed_state\'] ?? null,
                \'bed_desc\' => $item[\'bed_desc\'] ?? null,
                \'bed_created_at\' => $item[\'bed_created_at\'] ?? null,
                \'bed_updated_at\' => $item[\'bed_updated_at\'] ?? null,
                \'contract_resident_id\' => $item[\'contract_resident_id\'] ?? null,
                \'contract_payment_date\' => $item[\'contract_payment_date\'] ?? null,
                \'contract_payment_date_jalali\' => $item[\'contract_payment_date_jalali\'] ?? null,
                \'contract_bed_id\' => $item[\'contract_bed_id\'] ?? null,
                \'contract_state\' => $item[\'contract_state\'] ?? null,
                \'contract_start_date\' => $item[\'contract_start_date\'] ?? null,
                \'contract_start_date_jalali\' => $item[\'contract_start_date_jalali\'] ?? null,
                \'contract_end_date\' => $item[\'contract_end_date\'] ?? null,
                \'contract_end_date_jalali\' => $item[\'contract_end_date_jalali\'] ?? null,
                \'contract_created_at\' => $item[\'contract_created_at\'] ?? null,
                \'contract_updated_at\' => $item[\'contract_updated_at\'] ?? null,
                \'contract_deleted_at\' => $item[\'contract_deleted_at\'] ?? null,
                \'resident_full_name\' => $item[\'resident_full_name\'] ?? null,
                \'resident_phone\' => $item[\'resident_phone\'] ?? null,
                \'resident_age\' => $item[\'resident_age\'] ?? null,
                \'resident_birth_date\' => $item[\'resident_birth_date\'] ?? null,
                \'resident_job\' => $item[\'resident_job\'] ?? null,
                \'resident_referral_source\' => $item[\'resident_referral_source\'] ?? null,
                \'resident_form\' => $item[\'resident_form\'] ?? false,
                \'resident_document\' => $item[\'resident_document\'] ?? false,
                \'resident_rent\' => $item[\'resident_rent\'] ?? false,
                \'resident_trust\' => $item[\'resident_trust\'] ?? false,
                \'resident_created_at\' => $item[\'resident_created_at\'] ?? null,
                \'resident_updated_at\' => $item[\'resident_updated_at\'] ?? null,
                \'resident_deleted_at\' => $item[\'resident_deleted_at\'] ?? null,
                \'notes\' => $item[\'notes\'] ?? null,
                \'delay\' => $item[\'delay\'] ?? 0,
                \'last_synced_at\' => \\now(),
            ]);
            
            $createdCount++;
        }
        
        \\Log::info("Created {$createdCount} new residents from LIVE API");
        
        // 4. ذخیره cache
        \\Illuminate\\Support\\Facades\\Cache::put(\'residents_last_sync\', [
            \'time\' => \\now()->format(\'Y-m-d H:i:s\'),
            \'synced_count\' => $createdCount,
            \'created_count\' => $createdCount,
            \'updated_count\' => 0,
            \'deleted_count\' => $deletedCount,
            \'message\' => "دیتابیس از API هاست جایگزین شد. حذف شده: {$deletedCount}, ایجاد شده: {$createdCount}",
        ], \\now()->addDays(7));
        
        $totalInDb = \\App\\Models\\Resident::count();
        
        return \\response()->json([
            \'success\' => true,
            \'message\' => "همگام‌سازی موفق از API هاست: {$deletedCount} حذف، {$createdCount} ایجاد شد. مجموع: {$totalInDb} رکورد."
        ]);
        
    } catch (\\Exception $e) {
        \\Log::error(\'=== LIVE Sync failed ===\', [
            \'error\' => $e->getMessage(),
            \'trace\' => $e->getTraceAsString()
        ]);
        
        return \\response()->json([
            \'success\' => false,
            \'message\' => \'خطا در همگام‌سازی از API هاست: \' . $e->getMessage()
        ], 500);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007780000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Lo9WyashZVwdTF2C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jyOKRd7YbrMpdew7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/residents/sync',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1584:"function () {
    try {
        // اجرای Job همگام‌سازی
        $job = new \\App\\Jobs\\SyncResidentsFromApi();
        $job->handle();
        
        // دریافت آمار همگام‌سازی
        $lastSync = \\Illuminate\\Support\\Facades\\Cache::get(\'residents_last_sync\');
        
        // بررسی تعداد واقعی در دیتابیس
        $totalInDb = \\App\\Models\\Resident::count();
        $lastSyncedResident = \\App\\Models\\Resident::orderBy(\'last_synced_at\', \'desc\')->first();
        $lastSyncTime = $lastSyncedResident && $lastSyncedResident->last_synced_at 
            ? $lastSyncedResident->last_synced_at->format(\'Y-m-d H:i:s\') 
            : \'نامشخص\';
        
        return \\response()->json([
            \'success\' => true,
            \'message\' => \'Success\',
            \'data\' => [
                \'synced_count\' => $lastSync[\'synced_count\'] ?? 0,
                \'created_count\' => $lastSync[\'created_count\'] ?? 0,
                \'updated_count\' => $lastSync[\'updated_count\'] ?? 0,
                \'total_in_db\' => $totalInDb,
                \'last_sync_time\' => $lastSyncTime,
            ]
        ]);
    } catch (\\Exception $e) {
        \\Illuminate\\Support\\Facades\\Log::error(\'Error syncing residents from API route\', [
            \'error\' => $e->getMessage(),
            \'trace\' => $e->getTraceAsString(),
        ]);
        
        return \\response()->json([
            \'success\' => false,
            \'message\' => \'خطا در همگام‌سازی داده‌ها: \' . $e->getMessage(),
        ], 500);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000077a0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jyOKRd7YbrMpdew7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bkR3m5KDRsE4hjbp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/residents/sync-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:664:"function () {
    $lastSyncTime = \\Illuminate\\Support\\Facades\\Cache::get(\'residents_last_sync_time\');
    
    if ($lastSyncTime) {
        $lastSync = \\Illuminate\\Support\\Facades\\Cache::get(\'residents_last_sync\');
        return \\response()->json([
            \'synced\' => true,
            \'last_sync_time\' => $lastSyncTime->format(\'Y-m-d H:i:s\'),
            \'synced_count\' => $lastSync[\'synced_count\'] ?? 0,
            \'created_count\' => $lastSync[\'created_count\'] ?? 0,
            \'updated_count\' => $lastSync[\'updated_count\'] ?? 0,
        ]);
    }
    
    return \\response()->json([
        \'synced\' => false,
        \'last_sync_time\' => null,
    ]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000077c0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::bkR3m5KDRsE4hjbp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HwChn9xEyEqVLSF4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/residents/last-sync',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:2006:"function () {
    // ابتدا از cache بخوان
    $lastSync = \\Illuminate\\Support\\Facades\\Cache::get(\'residents_last_sync\');
    
    if ($lastSync && isset($lastSync[\'time\']) && $lastSync[\'time\'] !== null) {
        return \\response()->json([
            \'time\' => $lastSync[\'time\'],
            \'synced_count\' => $lastSync[\'synced_count\'] ?? 0,
            \'created_count\' => $lastSync[\'created_count\'] ?? 0,
            \'updated_count\' => $lastSync[\'updated_count\'] ?? 0,
            \'message\' => $lastSync[\'message\'] ?? \'همگام‌سازی انجام شده است\',
        ]);
    }
    
    // اگر cache وجود نداشت یا خالی بود، از آخرین sync در دیتابیس استفاده کن
    try {
        $lastSyncedResident = \\App\\Models\\Resident::orderBy(\'last_synced_at\', \'desc\')->first();
        $totalCount = \\App\\Models\\Resident::count();
        
        if ($lastSyncedResident && $lastSyncedResident->last_synced_at) {
            $time = $lastSyncedResident->last_synced_at instanceof \\Carbon\\Carbon 
                ? $lastSyncedResident->last_synced_at->format(\'Y-m-d H:i:s\')
                : $lastSyncedResident->last_synced_at;
                
            return \\response()->json([
                \'time\' => $time,
                \'synced_count\' => $totalCount,
                \'created_count\' => $totalCount,
                \'updated_count\' => 0,
                \'message\' => \'همگام‌سازی انجام شده است (از دیتابیس)\',
            ]);
        }
    } catch (\\Exception $e) {
        \\Illuminate\\Support\\Facades\\Log::error(\'Error getting last sync from database\', [
            \'error\' => $e->getMessage()
        ]);
    }
    
    // اگر هیچ داده‌ای پیدا نشد
    return \\response()->json([
        \'time\' => null,
        \'synced_count\' => 0,
        \'created_count\' => 0,
        \'updated_count\' => 0,
        \'message\' => \'هنوز همگام‌سازی انجام نشده است\',
    ]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000077e0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HwChn9xEyEqVLSF4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reports.bulk-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reports/bulk-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:142:"function () {
    // این Route برای حذف گروهی استفاده می‌شود
    return \\response()->json([\'success\' => true]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007800000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reports.bulk-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'categories.bulk-delete' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/categories/bulk-delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:142:"function () {
    // این Route برای حذف گروهی استفاده می‌شود
    return \\response()->json([\'success\' => true]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007820000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'categories.bulk-delete',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.resident.data' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/resident/{residentId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:2304:"function ($residentId) {
    try {
        $resident = \\App\\Models\\Resident::where(\'resident_id\', $residentId)->first();
        
        if (!$resident) {
            return \\response()->json([
                \'success\' => false,
                \'message\' => \'کاربر یافت نشد\'
            ], 404);
        }

        // دریافت گزارش‌های این کاربر
        $residentReports = \\App\\Models\\ResidentReport::where(\'resident_id\', $residentId)
            ->with(\'report\', \'report.category\')
            ->get()
            ->groupBy(function ($rr) {
                return $rr->report->api_endpoint_name ?? \'other\';
            })
            ->map(function ($reports, $key) {
                return $reports->map(function ($rr) {
                    return [
                        \'id\' => $rr->id,
                        \'report_id\' => $rr->report_id,
                        \'report_title\' => $rr->report->title ?? null,
                        \'report_category\' => $rr->report->category->name ?? null,
                        \'report_negative_score\' => $rr->report->negative_score ?? 0,
                        \'description\' => $rr->description,
                        \'notes\' => $rr->notes,
                        \'has_been_sent\' => $rr->has_been_sent,
                        \'is_checked\' => $rr->is_checked,
                        \'created_at\' => $rr->created_at ? $rr->created_at->format(\'Y-m-d H:i:s\') : null,
                    ];
                });
            });

        return \\response()->json([
            \'success\' => true,
            \'data\' => [
                \'resident_id\' => $resident->resident_id,
                \'contract_id\' => $resident->contract_id,
                \'full_name\' => $resident->resident_full_name,
                \'phone\' => $resident->resident_phone,
                \'reports\' => $residentReports,
            ]
        ]);
    } catch (\\Exception $e) {
        \\Illuminate\\Support\\Facades\\Log::error(\'Error fetching resident data\', [
            \'error\' => $e->getMessage(),
            \'trace\' => $e->getTraceAsString()
        ]);
        
        return \\response()->json([
            \'success\' => false,
            \'message\' => \'خطا در دریافت اطلاعات: \' . $e->getMessage()
        ], 500);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007840000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'api.resident.data',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.residents.all' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/residents/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:2335:"function () {
    try {
        $residents = \\App\\Models\\Resident::all();
        
        $residentsData = $residents->map(function ($resident) {
            // دریافت گزارش‌های این کاربر
            $residentReports = \\App\\Models\\ResidentReport::where(\'resident_id\', $resident->resident_id)
                ->with(\'report\', \'report.category\')
                ->get()
                ->groupBy(function ($rr) {
                    return $rr->report->api_endpoint_name ?? \'other\';
                })
                ->map(function ($reports, $key) {
                    return $reports->map(function ($rr) {
                        return [
                            \'id\' => $rr->id,
                            \'report_id\' => $rr->report_id,
                            \'report_title\' => $rr->report->title ?? null,
                            \'report_category\' => $rr->report->category->name ?? null,
                            \'report_negative_score\' => $rr->report->negative_score ?? 0,
                            \'description\' => $rr->description,
                            \'notes\' => $rr->notes,
                            \'has_been_sent\' => $rr->has_been_sent,
                            \'is_checked\' => $rr->is_checked,
                            \'created_at\' => $rr->created_at ? $rr->created_at->format(\'Y-m-d H:i:s\') : null,
                        ];
                    });
                });

            return [
                \'resident_id\' => $resident->resident_id,
                \'contract_id\' => $resident->contract_id,
                \'full_name\' => $resident->resident_full_name,
                \'phone\' => $resident->resident_phone,
                \'reports\' => $residentReports,
            ];
        });

        return \\response()->json([
            \'success\' => true,
            \'count\' => $residentsData->count(),
            \'data\' => $residentsData,
        ]);
    } catch (\\Exception $e) {
        \\Illuminate\\Support\\Facades\\Log::error(\'Error fetching all residents data\', [
            \'error\' => $e->getMessage(),
            \'trace\' => $e->getTraceAsString()
        ]);
        
        return \\response()->json([
            \'success\' => false,
            \'message\' => \'خطا در دریافت اطلاعات: \' . $e->getMessage()
        ], 500);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007860000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'api.residents.all',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.reports.endpoints' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/reports/endpoints',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:840:"function () {
    try {
        $reports = \\App\\Models\\Report::with(\'category\')
            ->orderBy(\'title\')
            ->get()
            ->map(function ($report) {
                return [
                    \'id\' => $report->id,
                    \'title\' => $report->title,
                    \'category\' => $report->category->name ?? null,
                    \'api_endpoint_name\' => $report->api_endpoint_name,
                    \'negative_score\' => $report->negative_score,
                ];
            });

        return \\response()->json([
            \'success\' => true,
            \'data\' => $reports
        ]);
    } catch (\\Exception $e) {
        return \\response()->json([
            \'success\' => false,
            \'message\' => \'خطا در دریافت اطلاعات: \' . $e->getMessage()
        ], 500);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007880000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'api.reports.endpoints',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'api.admin.violations' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/violations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:5678:"function () {
    try {
        // دریافت thresholdهای کارت زرد و قرمز از تنظیمات
        $yellowThreshold = (int) (\\App\\Models\\Constant::where(\'key\', \'yellow_card_threshold\')->first()?->value ?? 20);
        $redThreshold = (int) (\\App\\Models\\Constant::where(\'key\', \'red_card_threshold\')->first()?->value ?? 30);
        $yellowViolationCountThreshold = (int) (\\App\\Models\\Constant::where(\'key\', \'yellow_violation_count_threshold\')->first()?->value ?? 3);
        $redViolationCountThreshold = (int) (\\App\\Models\\Constant::where(\'key\', \'red_violation_count_threshold\')->first()?->value ?? 5);

        // دریافت کاربرانی که گزارش تخلف با امتیاز بالاتر از صفر دارند (به جز اخطار سررسید)
        $residentsWithViolations = \\App\\Models\\ResidentReport::join(\'reports\', \'resident_reports.report_id\', \'=\', \'reports.id\')
            ->where(\'reports.category_id\', 1) // دسته‌بندی تخلف
            ->where(\'reports.negative_score\', \'>\', 0) // امتیاز بالاتر از صفر
            ->where(\'reports.id\', \'!=\', 2) // حذف اخطار سررسید
            ->whereNotNull(\'resident_reports.resident_id\')
            ->select(\'resident_reports.resident_id\')
            ->distinct()
            ->get();

        $data = $residentsWithViolations->map(function ($item) use ($yellowThreshold, $redThreshold, $yellowViolationCountThreshold, $redViolationCountThreshold) {
            $residentId = $item->resident_id;
            
            // دریافت اطلاعات کاربر
            $resident = \\App\\Models\\Resident::where(\'resident_id\', $residentId)->first();
            
            // دریافت تخلف‌های کاربر (فقط دسته‌بندی تخلف، نه اطلاع‌رسانی و نه اخطار سررسید)
            $violations = \\App\\Models\\ResidentReport::join(\'reports\', \'resident_reports.report_id\', \'=\', \'reports.id\')
                ->where(\'reports.category_id\', 1)
                ->where(\'reports.negative_score\', \'>\', 0)
                ->where(\'reports.id\', \'!=\', 2) // حذف اخطار سررسید
                ->where(\'resident_reports.resident_id\', $residentId)
                ->select(
                    \'reports.id as report_id\',
                    \'reports.title as violation_type\',
                    \'reports.negative_score as violation_score\',
                    \'resident_reports.created_at\'
                )
                ->get();

            // گروه‌بندی تخلف‌های یکسان
            $groupedViolations = $violations->groupBy(\'report_id\')->map(function ($group) {
                $count = $group->count();
                $totalScore = $group->sum(\'violation_score\');
                
                return [
                    \'violation_type\' => $group->first()->violation_type,
                    \'violation_id\' => $group->first()->report_id,
                    \'count\' => $count,
                    \'single_score\' => $group->first()->violation_score,
                    \'total_score\' => $totalScore,
                ];
            })->values();

            // محاسبه مجموع کل امتیازات
            $totalViolationScore = $groupedViolations->sum(\'total_score\');
            
            // محاسبه بیشترین تعداد تخلف یکسان
            $maxRepeatedViolationCount = $groupedViolations->max(\'count\') ?? 0;

            // تعیین وضعیت کارت بر اساس thresholdها (فقط امتیاز یا تعداد تخلف یکسان)
            $cardStatus = \'none\';
            if ($totalViolationScore >= $redThreshold || $maxRepeatedViolationCount >= $redViolationCountThreshold) {
                $cardStatus = \'red\';
            } elseif ($totalViolationScore >= $yellowThreshold || $maxRepeatedViolationCount >= $yellowViolationCountThreshold) {
                $cardStatus = \'yellow\';
            }

            return [
                \'resident_id\' => $residentId,
                \'resident_name\' => $resident ? $resident->resident_full_name : \'نامشخص\',
                \'resident_phone\' => $resident ? $resident->resident_phone : null,
                \'unit_name\' => $resident ? $resident->unit_name : null,
                \'room_name\' => $resident ? $resident->room_name : null,
                \'bed_name\' => $resident ? $resident->bed_name : null,
                \'total_violation_score\' => $totalViolationScore,
                \'max_repeated_violation_count\' => $maxRepeatedViolationCount,
                \'card_status\' => $cardStatus,
                \'card_status_label\' => $cardStatus === \'red\' ? \'کارت قرمز\' : ($cardStatus === \'yellow\' ? \'کارت زرد\' : \'بدون کارت\'),
                \'yellow_threshold\' => $yellowThreshold,
                \'red_threshold\' => $redThreshold,
                \'yellow_violation_count_threshold\' => $yellowViolationCountThreshold,
                \'red_violation_count_threshold\' => $redViolationCountThreshold,
                \'violations\' => $groupedViolations,
            ];
        });

        return \\response()->json([
            \'success\' => true,
            \'count\' => $data->count(),
            \'data\' => $data,
        ]);
    } catch (\\Exception $e) {
        \\Illuminate\\Support\\Facades\\Log::error(\'Error fetching violations data\', [
            \'error\' => $e->getMessage(),
            \'trace\' => $e->getTraceAsString()
        ]);
        
        return \\response()->json([
            \'success\' => false,
            \'message\' => \'خطا در دریافت اطلاعات: \' . $e->getMessage()
        ], 500);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000078a0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'api.admin.violations',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:47:"C:\\laragon\\www\\atlas_report\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:1;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000078c0000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local.upload' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:47:"C:\\laragon\\www\\atlas_report\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:1;}s:8:"function";s:325:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ReceiveFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000078e0000000000000000";}}',
        'as' => 'storage.local.upload',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
