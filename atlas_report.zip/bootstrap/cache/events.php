<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\DatabaseRecordChanged' => 
    array (
      0 => 'App\\Listeners\\ProcessAutoSmsOnChange@handle',
    ),
    'App\\Events\\ResidentReportCreated' => 
    array (
      0 => 'App\\Listeners\\SendViolationSms@handle',
    ),
  ),
);